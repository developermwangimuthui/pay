<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="mubeenkhan" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css" media="all" />
    <link rel="stylesheet" href="style.css" type="text/css" media="all" />
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <link href="//db.onlinewebfonts.com/c/44994582bcefd02119158ff8b0d16b75?family=PayPal+Sans+Big" rel="stylesheet" type="text/css"/>
    <title>PayPal Form | PFA</title>
    <?php include_once( "functions.php" ); ?>
</head>

<body>
    <div class="container-fluid">
        <div class="row header">
            <div class="col-md-12">
                <div class="logo">
                    <a href="https://pfaccounts.com/">
                        <img src="images/pfa-2.png" height="50" width="100"/>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <?php session_start(); ?>
    <div class="container">
        <div class="wpmk-form">
            <p class="form-text-head">
                Make payment for services via PayPal
            </p>
            <div class="form-group">
                <label for="first-name">First Name</label>
                <input type="text" id="first-name" name="first-name" class="form-control" placeholder="First Name" required="required" />
                <div class="form-worning fn">Please fill this field</div>
            </div>
            
            <div class="form-group">
                <label for="last-name">Last Name</label>
                <input type="text" id="last-name" name="last-name" class="form-control" placeholder="Last Name" required="required" />
                <div class="form-worning ln">Please fill this field</div>
            </div>
            
            <div class="form-group">
                <label for="email-address">Paypal Email Address</label>
                <input type="email" id="email-address" name="email-address" class="form-control" placeholder="example@example.com" required="required" />
                <div class="form-worning pay">Please fill this field</div>
            </div>
            
            <div class="form-group">
                <label for="services">Services</label>
                <select name="service-name-select" class="form-control" id="services" required="required">
                    <option value="">Select Services</option>
                    <?php get_service_list(); ?>
                </select>
                <div class="form-worning sel">Please fill this field</div>
            </div>
            
            <div class="form-group" id="other-wrap">
                <label for="service-name-input">Other Service Detail</label>
                <input type="text" id="service-name-input" name="service-name-input" class="form-control" placeholder="Other Service Detail" />
                <div class="form-worning oth">Please fill this field</div>
            </div>
            
            <div class="amount-wrap">
                <div class="form-group if-error">
                    <label for="enter-amount">Enter Amount</label>
                    <input type="number" id="enter-amount" name="enter-amount" class="form-control" min="0" step=".01" placeholder="0.00" required="required" />
                    <div class="my-warning">Please add amount like : <code>10.00</code></div>
                    <div class="form-worning amo-war">Amount must be a numerical value with two decimal places</div>
                    <div class="form-worning amo">Please fill this field</div>
                </div>
            </div>
            
            <div class="amount-wrap">
                <div class="form-group">
                    <label for="currency-type">Currency Type</label>
                    <select class="form-control" name="currency-type" id="currency-type" required="required">
                        <option value="">Select Currency</option>
                        <option value="USD">USD</option>
                        <option value="GBP">GBP</option>
                        <option value="EUR">EUR</option>
                    </select>
                    <div class="form-worning cur">Please fill this field</div>
                </div>
            </div>
            <div style="clear: both;"></div>
            <div class="footer-wrap">
                <div class="checkbox">
                    <label for="paypal">
                        <img src="images/paypal.png" alt="Paypal"/>
                    </label>
                </div>
            </div>
            
            <div class="footer-wrap">
                <div class="mubeen-submit">
                    <input type="submit" name="submit-form" id="submit-form" class="btn btn-paypal" value="Pay via PayPal" />
                </div>
            </div>
            
            <div style="clear: both;"></div>
            <div class="form-footer">
                <div class="col-md-6 copy-right-text">
                    &copy; 2019 - <?php echo date( 'Y'); ?> Premium Freelancing Accounts. All rights reserved.
                </div>
                <div class="col-md-6">
                    <div class="footer-links">
                        <ul>
                            <li><a href="https://pfaccounts.com/#About_sec" target="_blank">About</a></li>
                            <li><a href="https://pfaccounts.com/#Contact_sec" target="_blank">Contact</a></li>
                            <li><a href="https://pfaccounts.com/#Key_sec" target="_blank">Services</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
        </div>
    </div>
    
    <div class="popup-window">
        <div class="popup-content">
            <div class="popup-close">X</div>
            <p>Please confirm your order</p>
            <table class="table table-bordered">
                <tr>
                    <th>First Name</th>
                    <th class="first-name">Mubeen uddin</th>
                </tr>
                <tr>
                    <th>Last Name</th>
                    <th class="last-name">Khan</th>
                </tr>
                <tr>
                    <th>Paypal Email Address</th>
                    <th class="email-address">mubeenkhan@live.com</th>
                </tr>
                <tr>
                    <th>Service</th>
                    <th class="service">Web Development</th>
                </tr>
                <tr>
                    <th>Amount</th>
                    <th class="amount">$400</th>
                </tr>
                <tr>
                    <th>Currency Type</th>
                    <th class="currency">USD</th>
                </tr>
            </table>
            
            <form action="<?php echo paypal_url(); ?>" method="post">
                <!-- Paypal -->
                <input type="hidden" name="cmd" value="_xclick" />
                <input type="hidden" name="charset" value="utf-8" />
                <input type="hidden" name="business" class="business" value="<?php paypal_email(); ?>" />
                <input type="hidden" name="item_name" class="item_name" value="" />
                <input type="hidden" name="item_number" value="services" />
                <input type="hidden" name="amount" class="amount-paypal" value="" />
                <input type="hidden" name="currency_code" class="currency_code" value="" />
                <input type='hidden' name='cancel_return' value='http://<?php echo $_SERVER['SERVER_NAME']?>/form/cancel.php' />
                <input type='hidden' name='return' value='http://<?php echo $_SERVER['SERVER_NAME']?>/form/success.php' />
                <!-- #Paypal -->
            <div class="mubeen-submit">
                <input type="submit" name="submit-form" id="submit-forms" class="btn btn-paypal" value="Pay via PayPal" />
            </div>
            
            </form>
            
        </div>
    </div>
    <script src="script.js"></script>
</body>
</html>