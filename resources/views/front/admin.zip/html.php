<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="content-type" content="text/html" />
	<meta name="author" content="mubeenkhan" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" type="text/css" media="all" />
	<title>HTML</title>
    <style>
    .header-top-banner{
        background-color: #0286e7;
    }
    .header-top-banner p{
        display: block;
        color: #FFFFFF;
        text-align: center;
    }
    </style>
</head>

<body>
<div class="container-fluid">
    <header class="row">
        <div class="header-top-banner col-md-12">
            <p>Hi i am information header top bar for design text</p>
        </div>
    </header>
</div>
</body>
</html>