<?php
session_start();

if(empty($_SESSION["firstname"])){
    header( "Location: http://demo.vfmseo.store/form/" );
}

include_once( 'admin/config.php' );
global $connection;

$payment_status     = 'Success';
$transaction        = $_GET['tx'];

$firstname          = $_SESSION["firstname"];
$lastname           = $_SESSION["lastname"];
$email_address      = $_SESSION["email_address"];
$services           = $_SESSION['services'];
$amount             = $_SESSION['amount'];
$amount_type        = $_SESSION['amount_type'];
$getways            = $_SESSION['getways'];

$queryUrl = "INSERT INTO user_details(firstname, lastname, email, services, amount, amount_type, getways, payment_status, transaction) VALUES ('".$firstname."', '".$lastname."', '".$email_address."','".$services."', '".$amount."', '".$amount_type."', '".$getways."', '".$payment_status."', '".$transaction."')";
$connection->query($queryUrl);

echo "<h3>$firstname $lastname, You have successfuly pay $amount_type $amount, we will send you email on $email_address soon.</h3>";
echo '<a href="http://demo.vfmseo.store/form/">Back</a>';
session_destroy();
unset($_REQUEST);
?>