<?php
session_start();
global $connection;
if(empty($_SESSION["firstname"])){
    header( "Location: http://demo.vfmseo.store/form/" );
}
define( 'HOSTNAME' , 'localhost' );
define( 'USERNAME' , 'vfmsre_php_db' );
define( 'PASSWORD' , 'vfmsre_php_db' );
define( 'DATABASE' , 'vfmsre_php_db' );

$connection = new mysqli( HOSTNAME, USERNAME, PASSWORD, DATABASE );

$payment_status     = 'Cancel';
$transaction        = $_GET['tx'];

$firstname          = $_SESSION["firstname"];
$lastname           = $_SESSION["lastname"];
$email_address      = $_SESSION["email_address"];
$services           = $_SESSION['services'];
$amount             = $_SESSION['amount'];
$amount_type        = $_SESSION['amount_type'];
$getways            = $_SESSION['getways'];

$queryUrl = "INSERT INTO user_details(firstname, lastname, email, services, amount, amount_type, getways, payment_status, transaction) VALUES ('".$firstname."', '".$lastname."', '".$email_address."','".$services."', '".$amount."', '".$amount_type."', '".$getways."', '".$payment_status."', '".$transaction."')";
$connection->query($queryUrl);

echo "<h3>$firstname $lastname, you did not made any payment and this payment is cancel now.</h3>";
echo '<a href="http://demo.vfmseo.store/form/">Back</a>';
session_destroy();
unset($_REQUEST);
?>